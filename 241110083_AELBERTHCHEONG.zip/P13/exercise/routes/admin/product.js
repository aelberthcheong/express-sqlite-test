import express from "express";
import Product from "../../models/product.js";

const router = express.Router();

router.get("/", async (req, res) => {
    const products = await Product.findAll();

    res.render("admin/product/index", {
        products,
        user: req.user
    });
});

router.get("/create", (req, res) => {
    res.render("admin/product/create");
});

router.get("/edit/:id", async (req, res) => {
    const product = await Product.findByPk(req.params.id);

    res.render("admin/product/edit", {
        product
    });
});

router.post("/api/products", async (req, res) => {
    const product = await Product.create({
        name: req.body.name,
        price: req.body.price,
    });

    res.json(product);
});

router.put("/api/product/:id", async (req, res) => {
    await Product.update(
        {
            name: req.body.name,
            price: req.body.price,
        },
        {
            where: {
                id: req.params.id,
            },
        }
    );

    res.json({ success: true });
});

router.delete("/api/product/:id", async (req, res) => {
    await Product.destroy({
        where: {
            id: req.params.id,
        },
    });

    res.json({ success: true });
});

export default router;