import express from "express";
import Supplier from "../../models/supplier.js";

const router = express.Router();

router.get("/", async (req, res) => {
    const suppliers = await Supplier.findAll();

    res.render("admin/supplier/index", {
        suppliers,
        user: req.user
    });
});

router.get("/create", (req, res) => {
    res.render("admin/supplier/create");
});

router.get("/edit/:id", async (req, res) => {
    const supplier = await Supplier.findByPk(
        req.params.id
    );

    res.render("admin/supplier/edit", {
        supplier
    });
});

router.post("/api/suppliers", async (req, res) => {
    const supplier = await Supplier.create({
        company_name: req.body.company_name,
        contact_name: req.body.contact_name,
        email: req.body.email,
        phone: req.body.phone,
        active: req.body.active,

        createdBy: req.user.username,
        updatedBy: req.user.username
    });

    res.json(supplier);
});

router.put("/api/supplier/:id", async (req, res) => {
    await Supplier.update(
        {
            company_name: req.body.company_name,
            contact_name: req.body.contact_name,
            email: req.body.email,
            phone: req.body.phone,
            active: req.body.active,

            updatedBy: req.user.username
        },
        {
            where: {
                id: req.params.id
            }
        }
    );

    res.json({
        success: true
    });
});

router.delete("/api/supplier/:id", async (req, res) => {
    await Supplier.destroy({
        where: {
            id: req.params.id
        }
    });

    res.json({
        success: true
    });
});

export default router;