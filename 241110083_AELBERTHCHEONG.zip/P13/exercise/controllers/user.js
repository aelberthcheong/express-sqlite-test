import User from "../models/user.js";
import jwt from "jsonwebtoken";

const login = (req, res) => {
    res.render("login", { message: "" });
};

const logout = (req, res) => {
    res.clearCookie("token");
    res.redirect("/");
};

const auth = async (req, res) => {
    const user = await User.findOne({
        where: {
            email: req.body.email,
            password: req.body.password,
        },
    });

    if (!user) {
        return res.render("login", {
            message: "Incorrect email or password",
        });
    }

    const token = jwt.sign(
        {
            id: user.id,
            username: user.username,
            email: user.email,
            isAdmin: user.isAdmin,
        },
        "secretjwt",
        {
            expiresIn: "1h",
        }
    );

    res.cookie("token", token, {
        httpOnly: true,
    });

    res.redirect("/");
};

export default { login, logout, auth };