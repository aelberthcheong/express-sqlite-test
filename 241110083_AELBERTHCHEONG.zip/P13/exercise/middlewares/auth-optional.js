import jwt from "jsonwebtoken";

export default (req, res, next) => {
    const token = req.cookies.token;

    if (token) {
        try {
            req.user = jwt.verify(token, "secretjwt");
        } catch {
            req.user = null;
        }
    }

    next();
};