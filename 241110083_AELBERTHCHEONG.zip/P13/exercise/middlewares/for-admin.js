export default (req, res, next) => {
    if (!req.user?.isAdmin) {
        return res.redirect("/forbidden");
    }

    next();
};