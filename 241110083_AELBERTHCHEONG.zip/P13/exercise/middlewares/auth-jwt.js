import passport from "../config/passport.js";

const authJwt = (req, res, next) => {
    passport.authenticate(
        "jwt",
        { session: false },
        (err, user) => {
            if (err) return res.json(err);

            if (!user) {
                return res.redirect("/user/login");
            }

            req.user = {
                id: user.id,
                username: user.username,
                email: user.email,
                isAdmin: user.isAdmin,
            };

            next();
        }
    )(req, res, next);
};

export default authJwt;