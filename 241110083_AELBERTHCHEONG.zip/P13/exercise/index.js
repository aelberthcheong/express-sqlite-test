import express from "express";
import cookieParser from "cookie-parser";
import passport from "./config/passport.js";

import { dirname, join } from "path";


import { sequelize } from "./models/model.js";
import User from "./models/user.js";
import Product from "./models/product.js";
import Supplier from "./models/supplier.js";

import authJwt from "./middlewares/auth-jwt.js";
import authOptional from "./middlewares/auth-optional.js";
import forAdmin from "./middlewares/for-admin.js";

import userRoutes from "./routes/user.js";
import adminProductRoutes from "./routes/admin/product.js";
import adminSupplierRoutes from "./routes/admin/supplier.js";
import { fileURLToPath } from "url";

const app = express();
const __filepath = fileURLToPath(import.meta.url);
const __dirname = dirname(__filepath);

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use(cookieParser());
app.use(passport.initialize());

app.set("view engine", "ejs");
app.set("views", join(__dirname, "views"));

app.use("/user", userRoutes);

app.use("/admin/product", authJwt, forAdmin, adminProductRoutes);
app.use("/admin/supplier", authJwt, forAdmin, adminSupplierRoutes);

app.get("/", authOptional, async (req, res) => {
    const products = await Product.findAll();
    const suppliers = await Supplier.findAll();

    res.render("index", {
        user: req.user || "",
        products,
        suppliers,
    });
});

app.get("/forbidden", authJwt, (req, res) => {
    res.render("forbidden", {
        user: req.user || "",
    });
});

await sequelize.sync();
app.listen(3001, () => {
    console.log(`server berjalan di port 3001...`)
});