import passport from "passport";
import { Strategy, ExtractJwt } from "passport-jwt";
import User from "../models/user.js";

passport.use(
    new Strategy(
        {
            jwtFromRequest: ExtractJwt.fromExtractors([
                (req) => req.cookies.token,
            ]),
            secretOrKey: "secretjwt",
        },
        async (payload, done) => {
            try {
                const user = await User.findByPk(payload.id);

                if (!user) {
                    return done(null, false);
                }

                return done(null, user);
            } catch (err) {
                return done(err, false);
            }
        }
    )
);

export default passport;