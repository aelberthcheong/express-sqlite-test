import { sequelize, DataTypes } from "./model.js";

const User = sequelize.define("user", {
    username: {
        type: DataTypes.STRING,
        unique: true,
    },
    email: DataTypes.STRING,
    password: DataTypes.STRING,
    active: DataTypes.TINYINT,
    isAdmin: DataTypes.BOOLEAN,
});

export default User;