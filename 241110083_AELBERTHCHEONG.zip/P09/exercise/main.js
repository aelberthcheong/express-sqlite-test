import express from "express";
import { Sequelize, DataTypes } from "sequelize";

const app = express();
app.use(express.json());

const sequelize = new Sequelize("web", "root", '', {
    host: "localhost",
    dialect: "mysql",
    logging: false,
});

const Product = sequelize.define("Product", {
    product_id: {
        type: DataTypes.INTEGER(11),
        primaryKey: true,   
        autoIncrement: true,
        allowNull: false
    },
    product_name: {
        type: DataTypes.STRING(200),
        allowNull: false
    },
    product_price: {
        type: DataTypes.INTEGER(11),
        allowNull: false
    }
}, {
    tableName: "product",
    timestamps: false
});

sequelize.authenticate()
    .then(() => console.log("Connected to MYSQL via Sequelize"))
    .catch(err => console.error("Unable to connect:", err));

app.use(function (req, res, next) {
    console.log("Request URL   :", req.url);
    console.log("Request Method:", req.method);
    next();
});

app.get("/api/products", async function(req, res) {
    try {
        const products = await Product.findAll();
        res.json(products);
    } catch (err) {
        res.status(500).json({
            error: new Error(`Unable to execute query!`, {cause: err})
        });
    }
});

app.get("/api/products/:id", async function(req, res) {
    try {
        const product = await Product.findByPk(req.params.id);
        if (!product) {
            res.status(404).json({
                message: "product not found"
            });
            return;
        }
        res.json(product);
    } catch (err) {
        res.status(500).json({
            error: new Error(`Unable to execute query!`, {cause: err})
        });
    }
});

app.post("/api/products", async function(req, res) {
    try {
        const { 
            product_name: productName, 
            product_price: productPrice 
        } = req.body;

        if (isNaN(productPrice)) {
            res.status(400).json({
                error: "product_price wajib diisi dengan angka"
            });
            return;
        }

        if (productPrice <= 0) {
            res.status(400).json({
                error: "product_price tidak boleh <= 0"
            });
            return;
        }

        const newProduct = await Product.create({ product_name, product_price });
        res.json(newProduct);
    } catch (err) {
        res.status(500).json({
            error: new Error(`Unable to execute query!`, {cause: err})
        });
    }
});

app.put("/api/products/:id", async function(req, res) {
    try {
        const { 
            product_name: productName, 
            product_price: productPrice 
        } = req.body;
        const [updated] = await Product.update(
            { productName, productPrice },
            {where: { product_id: req.params.id }}
        )
        if (updated) {
            res.json({
                message: "product updated"
            })
        } else {
            res.status(404).json({ message: "product not found"})
        }
    } catch (err) {
        res.status(500).json({
            error: new Error(`Unable to execute query!`, {cause: err})
        });
    }
});

app.delete("/api/products/:id", async function(req, res) {
    try {
        const deleted = await Product.destroy({
            where: { product_id: req.params.id }
        });

        if (deleted) {
            res.json({ message: "product deleted" });
        } else {
            res.status(404).json({ message: "product not found" });
        }
    } catch (err) {
        res.status(500).json({
            error: new Error(`Unable to execute query!`, {cause: err})
        });
    }
});

app.use(function (err, req, res, next) {
    if (res.statusCode >= 500) {
        res.send("Something broke!");
    }
})

app.listen(3000, () => {
    console.log(`Server running at http://127.0.0.1:3000`);
})