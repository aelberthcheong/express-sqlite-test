import express from "express";
import mysql from "mysql2/promise";

const app = express();

const PORT = process.env.PORT || 8080;
const HOST = "0.0.0.0";

// Railway provides environment variables
const conn = await mysql.createConnection({
    uri: process.env.MYSQL_URL || process.env.DATABASE_URL,
});

// API endpoint
app.get("/api/quotes", async (req, res) => {
    try {
        const [rows] = await conn.query(`
            SELECT id, text, author, created_at
            FROM quotes
            ORDER BY RAND()
            LIMIT 9
        `);

        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({
            error: "Failed to retrieve quotes",
        });
    }
});

// HTML endpoint
app.get("/quotes", async (req, res) => {
    try {
        const [quotes] = await conn.query(`
            SELECT text, author
            FROM quotes
            ORDER BY RAND()
            LIMIT 9
        `);

        const cards = quotes
            .map(
                (q) => `
                <div class="card">
                    <p class="quote">"${q.text}"</p>
                    <p class="author">— ${q.author}</p>
                </div>
            `
            )
            .join("");

        res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Daily Inspiration</title>
<style>
body{
    margin:0;
    font-family:Arial,sans-serif;
    background:#f4f4f9;
}
h1{
    text-align:center;
    color:#333;
    margin:30px 0;
}
.container{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:20px;
    max-width:1200px;
    margin:auto;
    padding:20px;
}
.card{
    background:white;
    border-radius:10px;
    padding:20px;
    box-shadow:0 4px 8px rgba(0,0,0,.15);
}
.quote{
    font-size:18px;
    color:#444;
}
.author{
    margin-top:15px;
    text-align:right;
    font-weight:bold;
    color:#666;
}
</style>
</head>
<body>
<h1>🌟 Daily Inspiration 🌟</h1>
<div class="container">
${cards}
</div>
</body>
</html>
        `);
    } catch (err) {
        console.error(err);
        res.status(500).send("Internal Server Error");
    }
});

app.listen(PORT, HOST, () => {
    console.log(`Server running at http://${HOST}:${PORT}`);
});