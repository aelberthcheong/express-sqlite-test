import moment from "moment";

/** @typedef {{username: string, text: string, time: string}} User */

/**
 * @param {string} username 
 * @param {string} text 
 * @returns {User}
 */
export function formatMessage(username, text) {
    return {    
        username,
        text,
        time: moment().format("h:mm a"),
    };
}