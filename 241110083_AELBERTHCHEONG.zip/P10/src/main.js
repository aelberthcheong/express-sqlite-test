import { createApp } from 'vue';
import App from './App.vue';
import { createRouter, createWebHistory } from 'vue-router'; // Vue Router 4 imports

// Import your components
import Create from "./components/ProductAdd.vue";
import Edit from "./components/ProductEdit.vue";
import Index from "./components/ProductList.vue";

// Define your routes
const routes = [
    {
        name: "Create",
        path: "/create",
        component: Create
    },
    {
        name: "Edit",
        path: "/edit/:id", // Fixed the colon placement here
        component: Edit
    },
    {
        name: "Index",
        path: "/",
        component: Index
    },
];

const router = createRouter({
    history: createWebHistory(),
    routes: routes
});

const app = createApp(App);

app.use(router);
app.mount('#app');
