<template>
    <div>
        <router-link :to="{ name: 'Create' }" class="button is-success" style="margin-top:10px">Add New</router-link>
        <table class="table is-striped is-bordered mt-3 is-fullwidth" style="margin:10px auto">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Product Price</th>
                    <th class="has-text-centered">Actions</th>
                </tr>
            </thead>
            
            <tbody>
                <tr v-for="item in items" :key="item.product_id">
                    <td>{{ item.product_name }}</td>
                    <td>{{ item.product_price }}</td>
                    <td>
                        <router-link
                            :to="{ name: 'Edit', params: { id: item.product_id } }"
                            class="button is-warning is-small"
                        >Edit</router-link>
                        <a class="button is-danger is-small" style="margin-left:5px" @click="deleteProduct(item.product_id)">
                        Delete</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
    import axios from "axios";
    export default {
        name: "ProductList",
        data() {
            return {
                items: [],
            };
        },
        created() {
            this.getProducts();
        },
        methods: {
            async getProducts() {
                try {
                    const res = await axios.get("http://localhost:3000/api/products");
                    this.items = res.data.response;
                } catch (err) {
                    console.error(err);
                }
            },
            async deleteProduct(id) {
                try {
                    await axios.delete(`http://localhost:3000/api/products/${id}`);
                    this.getProducts();
                } catch (err) {
                    console.error(err);
                }
            }
        }
   };
</script>

<style>
</style>