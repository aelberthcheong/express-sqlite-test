import express from 'express';
import Supplier from './models/supplier.js';
import { sequelize } from './models/model.js';
import validator from 'validator';
 
const app = express();
const hostname = '127.0.0.1';
const port = 3001;
 
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
 
// Validation function
const validateSupplier = (data) => {
    const errors = [];
 
    // company_name - required, string only
    if (!data.company_name || data.company_name.trim() === '') {
        errors.push('Company name is required');
    } else if (!validator.isAlphanumeric(data.company_name.replace(/\s/g, ''))) {
        errors.push('Company name must contain letters and numbers only');
    }
 
    // contact_name - required, letters only
    if (!data.contact_name || data.contact_name.trim() === '') {
        errors.push('Contact name is required');
    } else if (!validator.isAlphanumeric(data.contact_name.replace(/\s/g, ''))) {
        errors.push('Contact name must contain letters only');
    }
 
    // email - required, valid email format
    if (!data.email || data.email.trim() === '') {
        errors.push('Email is required');
    } else if (!validator.isEmail(data.email)) {
        errors.push('Email format is invalid');
    }
 
    // phone - required, numeric only
    if (!data.phone || data.phone.trim() === '') {
        errors.push('Phone is required');
    } else if (!validator.isMobilePhone(data.phone)) {
        errors.push('Phone number is invalid');
    }
 
    // active - required, must be 0 or 1
    if (data.active === undefined || data.active === '') {
        errors.push('Active is required');
    } else if (!validator.isInt(String(data.active), { min: 0, max: 1 })) {
        errors.push('Active must be 0 or 1');
    }
 
    return errors;
};
 
// View Routes
app.get('/', (req, res) => {
    Supplier.findAll().then((results) => {
        res.render('index', { suppliers: results });
    });
})
 
app.get('/create', (req, res) => {
    res.render('create');
})
 
app.get('/edit/:id', (req, res) => {
    Supplier.findOne({ where: { id: req.params.id } }
    ).then((results) => {
        res.render('edit', { supplier: results });
    })
})
 
app.post('/api/suppliers', (req, res) => {
    const errors = validateSupplier(req.body);
    if (errors.length > 0) {
        return res.json({ status: 400, error: errors, Response: {} });
    }
 
    Supplier.create({
        company_name: req.body.company_name,
        contact_name: req.body.contact_name,
        email: req.body.email,
        phone: req.body.phone,
        active: req.body.active
    }).then((results) => {
        res.json({
            status: 200,
            error: null,
            Response: {
                id: results.id,
                createdAt: results.createdAt,
                updatedAt: results.updatedAt
            }
        });
    }).catch(err => {
        res.json({ status: 502, error: err });
    })
})
 
app.put('/api/supplier/:id', (req, res) => {
    // validate id is integer
    if (!validator.isInt(String(req.params.id))) {
        return res.json({ status: 400, error: ['ID must be an integer'], Response: {} });
    }
 
    const errors = validateSupplier(req.body);
    if (errors.length > 0) {
        return res.json({ status: 400, error: errors, Response: {} });
    }
    
    Supplier.update({
        company_name: req.body.company_name,
        contact_name: req.body.contact_name,
        email: req.body.email,
        phone: req.body.phone,
        active: req.body.active
    }, { where: { id: req.params.id } }
    ).then((results) => {
        res.json({ status: 200, error: null, Response: [1] });
    }).catch(err => {
        res.json({ status: 502, error: err });
    })
})
 
app.delete('/api/supplier/:id', (req, res) => {
    // validate id is integer
    if (!validator.isInt(String(req.params.id))) {
        return res.json({ status: 400, error: ['ID must be an integer'], Response: {} });
    }
 
    Supplier.destroy({ where: { id: req.params.id } }
    ).then((deleted) => {
        if (deleted === 0) {
            return res.json({ status: 404, error: ['Supplier not found'], Response: {} });
        }
        res.json({ status: 200, error: null, Response: { id: req.params.id } });
    }).catch(err => {
        res.json({ status: 500, error: err, Response: {} });
    })
})
 
// Sync database then start server
sequelize.sync().then(() => {
    console.log('Database synced');
    app.listen(port, () => {
        console.log(`Server running at ${hostname}:${port}`);
    });
}).catch(err => {
    console.error('Failed to sync database:', err);
});