import {Sequelize, DataTypes} from 'sequelize';
 
const sequelize = new Sequelize("241110083", "root", "", {
    dialect: "sqlite",
    storage: "./241110083.db"
});
 
export {sequelize, DataTypes};